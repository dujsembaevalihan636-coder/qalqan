import type { AnalysisResult } from "@/lib/types";
import { SCHEME_LABELS, VERDICT_LABELS } from "@/lib/types";

const SIGNAL: Record<string, { color: string; glow: string; ring: string }> = {
  red: { color: "#ff4d4d", glow: "rgba(255,77,77,0.14)", ring: "rgba(255,77,77,0.4)" },
  yellow: { color: "#ffb829", glow: "rgba(255,184,41,0.12)", ring: "rgba(255,184,41,0.4)" },
  green: { color: "#35d07f", glow: "rgba(53,208,127,0.12)", ring: "rgba(53,208,127,0.4)" },
};

export function VerdictCard({ result }: { result: AnalysisResult }) {
  const s = SIGNAL[result.verdict];
  return (
    <div
      className="fade-up rounded-[24px] p-6 md:p-8"
      style={{
        background: `linear-gradient(180deg, ${s.glow}, rgba(255,255,255,0.015))`,
        border: `1px solid ${s.ring}`,
      }}
    >
      <div className="flex flex-wrap items-center gap-4">
        <span
          className="relative flex h-14 w-14 shrink-0 items-center justify-center rounded-full"
          style={{ background: s.color }}
        >
          <span
            className="absolute inset-0 rounded-full"
            style={{ boxShadow: `0 0 40px 6px ${s.ring}` }}
          />
          <span className="relative text-2xl">
            {result.verdict === "red" ? "✕" : result.verdict === "yellow" ? "!" : "✓"}
          </span>
        </span>
        <div>
          <p className="t-label" style={{ color: s.color }}>
            {VERDICT_LABELS[result.verdict]} · {SCHEME_LABELS[result.schemeType]}
          </p>
          <p className="t-subheading mt-1 max-w-xl text-white">{result.summary}</p>
        </div>
      </div>

      {result.redFlags.length > 0 && (
        <div className="mt-7">
          <p className="t-label mb-3 text-[#ffb829]">Красные флаги</p>
          <ul className="space-y-3">
            {result.redFlags.map((f, i) => (
              <li key={i} className="flex gap-3">
                <span
                  className="mt-[9px] h-1.5 w-1.5 shrink-0 rounded-full"
                  style={{ background: s.color }}
                />
                <span className="t-body-sm text-[#dcdcdc]">{f}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {result.checklist.length > 0 && (
        <div className="mt-7">
          <p className="t-label mb-3 text-[#ffb829]">
            Стоп. Задай эти вопросы, прежде чем соглашаться
          </p>
          <ol className="space-y-3">
            {result.checklist.map((q, i) => (
              <li key={i} className="flex gap-3">
                <span className="t-caption mt-[3px] flex h-5 w-5 shrink-0 items-center justify-center rounded-full border border-white/20 text-white/70">
                  {i + 1}
                </span>
                <span className="t-body-sm text-[#dcdcdc]">{q}</span>
              </li>
            ))}
          </ol>
        </div>
      )}

      <p className="mt-6 text-[11px] uppercase tracking-[0.14em] text-[#6b6b6b]">
        Анализ: {result.engine === "claude" ? "Claude (Anthropic)" : "эвристика (демо-режим)"} · регион: {result.region ?? "—"}
      </p>
    </div>
  );
}
