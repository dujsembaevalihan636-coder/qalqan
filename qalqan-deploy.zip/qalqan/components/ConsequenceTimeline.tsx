import type { ConsequenceStep } from "@/lib/types";

const SEV: Record<ConsequenceStep["severity"], string> = {
  info: "#8052ff",
  warning: "#ffb829",
  danger: "#ff4d4d",
};

export function ConsequenceTimeline({ steps }: { steps: ConsequenceStep[] }) {
  return (
    <div className="fade-up relative mt-8">
      {/* вертикальная линия */}
      <div className="absolute bottom-2 left-[11px] top-2 w-px bg-gradient-to-b from-[#8052ff] via-[#ffb829] to-[#ff4d4d] opacity-50" />
      <ul className="space-y-8">
        {steps.map((s, i) => (
          <li
            key={i}
            className="relative pl-10 fade-up"
            style={{ animationDelay: `${i * 90}ms` }}
          >
            <span
              className="absolute left-0 top-1 flex h-[23px] w-[23px] items-center justify-center rounded-full"
              style={{ background: "#000", border: `2px solid ${SEV[s.severity]}` }}
            >
              <span
                className="h-2 w-2 rounded-full"
                style={{ background: SEV[s.severity] }}
              />
            </span>
            <p
              className="text-[11px] font-semibold uppercase tracking-[0.16em]"
              style={{ color: SEV[s.severity] }}
            >
              {s.time}
            </p>
            <p className="t-subheading mt-1 text-white">{s.event}</p>
            <p className="t-body-sm mt-1.5 max-w-xl text-[#9a9a9a]">{s.detail}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}
