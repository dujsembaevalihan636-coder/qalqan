// Модуль F — легальная альтернатива. Курируемый список (честно: для хакатона
// это направление развития, не биржа вакансий).

const JOBS = [
  {
    title: "enbek.kz",
    tag: "Госпортал труда",
    desc: "Официальные вакансии и подработки, в т.ч. молодёжная практика и субсидируемые места.",
  },
  {
    title: "«Жасыл Ел» / волонтёрские программы",
    tag: "Сезонная занятость",
    desc: "Оплачиваемые студенческие и экологические отряды с официальным оформлением.",
  },
  {
    title: "Freelance-биржи (Kwork, Upwork)",
    tag: "Удалёнка по-настоящему",
    desc: "Дизайн, тексты, переводы, монтаж — платят за навык, а не за «прогон денег через карту».",
  },
  {
    title: "Молодёжные ресурсные центры",
    tag: "Оффлайн в твоём городе",
    desc: "Помогают с первой легальной подработкой, стажировками и оформлением документов.",
  },
];

export function LegalAlternatives() {
  return (
    <div className="grid gap-6 md:grid-cols-2">
      {JOBS.map((j) => (
        <div
          key={j.title}
          className="group rounded-[24px] border border-white/10 p-6 transition-colors hover:border-[#8052ff]/50"
        >
          <p className="t-label text-[#35d07f]">{j.tag}</p>
          <p className="t-subheading mt-2 text-white">{j.title}</p>
          <p className="t-body-sm mt-2 text-[#9a9a9a]">{j.desc}</p>
        </div>
      ))}
    </div>
  );
}
