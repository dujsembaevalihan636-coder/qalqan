"use client";

import { Map3D } from "./Map3D";

// Hero-визуал: 3D-карта угроз Казахстана, автоповорот, без ручного управления.
export function HeroMap() {
  return <Map3D autoRotate interactive={false} showChip />;
}
