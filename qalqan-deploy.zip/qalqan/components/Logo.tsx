// Логотип Qalqan — угловатый щит-фрагмент с фиолетово-бирюзовым градиентом,
// эхом триангулярных частиц из hero-визуализации.
export function Logo({ size = 26 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden
    >
      <defs>
        <linearGradient id="qalqan-logo" x1="4" y1="2" x2="28" y2="30">
          <stop offset="0" stopColor="#8052ff" />
          <stop offset="1" stopColor="#15846e" />
        </linearGradient>
      </defs>
      <path
        d="M16 2 L28 7 V16 C28 23 22.5 28 16 30.5 C9.5 28 4 23 4 16 V7 Z"
        fill="url(#qalqan-logo)"
      />
      <path
        d="M16 9 L16 24 M16 9 L11 11.5 M16 9 L21 11.5"
        stroke="#ffffff"
        strokeWidth="1.6"
        strokeLinecap="round"
        opacity="0.9"
      />
    </svg>
  );
}
