"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Logo } from "./Logo";

const LINKS = [
  { href: "/", label: "Проверка" },
  { href: "/map", label: "Карта угроз" },
  { href: "/parents", label: "Родителям" },
];

export function Nav() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  // Прозрачный навбар на самом верху, тёмный со «стеклом» — как только
  // контент начинает уезжать под него (иначе текст просвечивает сквозь панель).
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className="sticky top-0 z-50 transition-colors duration-300"
      style={{
        background: scrolled || open ? "rgba(0,0,0,0.72)" : "transparent",
        backdropFilter: scrolled || open ? "blur(14px)" : "none",
        WebkitBackdropFilter: scrolled || open ? "blur(14px)" : "none",
        borderBottom: scrolled
          ? "1px solid rgba(255,255,255,0.08)"
          : "1px solid transparent",
      }}
    >
      <div className="mx-auto flex max-w-[1280px] items-center justify-between px-5 py-4 md:px-8">
        <Link href="/" className="flex items-center gap-3" onClick={() => setOpen(false)}>
          <Logo />
          <span className="text-[19px] font-medium tracking-tight text-white">
            Qalqan
          </span>
          <span className="hidden text-[11px] uppercase tracking-[0.2em] text-[#6b6b6b] sm:inline">
            Қалқан · щит
          </span>
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          {LINKS.map((l) => {
            const active = pathname === l.href;
            return (
              <Link
                key={l.href}
                href={l.href}
                className="text-[13px] font-semibold uppercase tracking-[0.12em] transition-colors"
                style={{ color: active ? "#ffffff" : "#9a9a9a" }}
              >
                {l.label}
              </Link>
            );
          })}
          <Link href="/#checker" className="btn-iris !px-5 !py-2.5">
            Проверить
          </Link>
        </nav>

        <button
          className="flex h-10 w-10 items-center justify-center md:hidden"
          onClick={() => setOpen((v) => !v)}
          aria-label="Меню"
        >
          <div className="space-y-[5px]">
            <span className="block h-[1.5px] w-6 bg-white" />
            <span className="block h-[1.5px] w-6 bg-white" />
            <span className="block h-[1.5px] w-6 bg-white" />
          </div>
        </button>
      </div>

      {open && (
        <div className="border-t border-white/10 bg-black/95 backdrop-blur md:hidden">
          <nav className="mx-auto flex max-w-[1280px] flex-col gap-1 px-5 py-4">
            {LINKS.map((l) => (
              <Link
                key={l.href}
                href={l.href}
                onClick={() => setOpen(false)}
                className="py-3 text-[15px] font-medium"
                style={{ color: pathname === l.href ? "#fff" : "#9a9a9a" }}
              >
                {l.label}
              </Link>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
}
