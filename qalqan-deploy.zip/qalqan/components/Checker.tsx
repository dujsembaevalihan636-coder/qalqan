"use client";

import { useState } from "react";
import type { AnalysisResult, FlaggedAccount, ConsequenceStep } from "@/lib/types";
import { KIND_LABELS } from "@/lib/types";
import { detectCity } from "@/lib/geo";
import { VerdictCard } from "./VerdictCard";
import { ConsequenceTimeline } from "./ConsequenceTimeline";
import { Spinner } from "./Spinner";

type Mode = "text" | "account";

const EXAMPLES = [
  "Привет! Ищу подработку студентам. Нужно просто принять перевод на свою карту Kaspi и перекинуть дальше — оставляешь себе 10%. Работа на дому, без опыта, до 300к в месяц. Только сегодня набираю, пиши в тг.",
  "Здравствуйте, это служба безопасности банка. По вашей карте подозрительная операция. Чтобы отменить, срочно продиктуйте код из SMS и срок действия карты.",
  "Инвест-платформа: вкладываешь 50 000 ₸ — через месяц гарантированно 30% сверху. Приведёшь друга — ещё бонус. Мест мало, успей зайти.",
];

const ACCOUNT_EXAMPLES = ["4400 4302 1122 3344", "@easy_money_kz", "+7 707 555 21 43"];

export function Checker() {
  const [mode, setMode] = useState<Mode>("text");
  const [input, setInput] = useState("");
  const [region, setRegion] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [account, setAccount] = useState<{
    found: boolean;
    kind: string;
    account: FlaggedAccount | null;
  } | null>(null);

  const [conseq, setConseq] = useState<ConsequenceStep[] | null>(null);
  const [conseqLoading, setConseqLoading] = useState(false);
  const [locating, setLocating] = useState(false);

  async function useMyLocation() {
    setLocating(true);
    const r = await detectCity();
    if (r.ok) setRegion(r.city.name);
    setLocating(false);
  }

  function reset() {
    setAnalysis(null);
    setAccount(null);
    setConseq(null);
    setError(null);
  }

  async function run() {
    if (!input.trim()) return;
    setLoading(true);
    reset();
    try {
      if (mode === "text") {
        const res = await fetch("/api/analyze", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text: input, region }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Ошибка");
        setAnalysis(data as AnalysisResult);
      } else {
        const res = await fetch("/api/check-account", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ value: input }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Ошибка");
        setAccount(data);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Что-то пошло не так");
    } finally {
      setLoading(false);
    }
  }

  async function showConsequences() {
    setConseqLoading(true);
    try {
      const res = await fetch("/api/consequences", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          scenario:
            analysis?.summary ??
            "Согласился стать дроппером: дал карту и принял чужой перевод за процент.",
        }),
      });
      const data = await res.json();
      setConseq(data.steps as ConsequenceStep[]);
    } finally {
      setConseqLoading(false);
    }
  }

  const showConseqButton =
    analysis && analysis.verdict !== "green" && !conseq;

  return (
    <div id="checker" className="scroll-mt-24">
      {/* Переключатель режимов */}
      <div className="inline-flex rounded-full border border-white/12 p-1">
        {(["text", "account"] as Mode[]).map((m) => (
          <button
            key={m}
            onClick={() => {
              setMode(m);
              setInput("");
              reset();
            }}
            className="rounded-full px-5 py-2 text-[13px] font-semibold uppercase tracking-[0.1em] transition-colors"
            style={{
              background: mode === m ? "#8052ff" : "transparent",
              color: mode === m ? "#fff" : "#9a9a9a",
            }}
          >
            {m === "text" ? "Сообщение" : "Реквизит"}
          </button>
        ))}
      </div>

      <div className="mt-5">
        {mode === "text" ? (
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Вставь сюда подозрительное сообщение из Telegram / WhatsApp / Instagram…"
            rows={5}
            className="field resize-none"
          />
        ) : (
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Номер карты, кошелёк, телефон или @ник"
            className="field"
          />
        )}
      </div>

      {mode === "text" && (
        <div className="mt-3 flex gap-2">
          <input
            value={region}
            onChange={(e) => setRegion(e.target.value)}
            placeholder="Твой город (необязательно) — попадёт на карту угроз"
            className="field !py-3.5 !text-[15px]"
          />
          <button
            type="button"
            onClick={useMyLocation}
            disabled={locating}
            title="Определить мой город"
            className="shrink-0 rounded-[20px] border border-white/12 px-4 text-[14px] text-[#bdbdbd] transition-colors hover:border-white/30 hover:text-white"
          >
            {locating ? <Spinner /> : "📍"}
          </button>
        </div>
      )}

      {/* Примеры */}
      <div className="mt-4 flex flex-wrap items-center gap-2">
        <span className="text-[12px] uppercase tracking-[0.14em] text-[#6b6b6b]">
          Пример:
        </span>
        {(mode === "text" ? EXAMPLES : ACCOUNT_EXAMPLES).map((ex, i) => (
          <button
            key={i}
            onClick={() => setInput(ex)}
            className="rounded-full border border-white/12 px-3 py-1.5 text-[12px] text-[#bdbdbd] transition-colors hover:border-white/30 hover:text-white"
          >
            {mode === "text" ? `Схема ${i + 1}` : ex}
          </button>
        ))}
      </div>

      <div className="mt-6 flex items-center gap-5">
        <button onClick={run} disabled={loading || !input.trim()} className="btn-iris">
          {loading ? <Spinner /> : null}
          {loading ? "Проверяю…" : mode === "text" ? "Проверить сообщение" : "Проверить по базе"}
        </button>
        {(analysis || account) && (
          <button onClick={reset} className="btn-ghost">
            Очистить
          </button>
        )}
      </div>

      {error && (
        <p className="mt-5 text-[14px] text-[#ff4d4d]">{error}</p>
      )}

      {/* Результат: текст */}
      {analysis && (
        <div className="mt-8">
          <VerdictCard result={analysis} />

          {showConseqButton && (
            <div className="mt-6">
              <button
                onClick={showConsequences}
                disabled={conseqLoading}
                className="btn-iris"
              >
                {conseqLoading ? <Spinner /> : null}
                {conseqLoading ? "Считаю траекторию…" : "Показать последствия →"}
              </button>
              <p className="t-caption mt-2 text-[#6b6b6b]">
                Что реально произойдёт, если согласиться. По ст. 232-1 УК РК.
              </p>
            </div>
          )}

          {conseq && (
            <div className="mt-10">
              <p className="t-label mb-1 text-[#ff4d4d]">Траектория последствий</p>
              <p className="t-heading-sm max-w-xl text-white">
                5 000 ₸ сегодня — и до 7 лет потом.
              </p>
              <ConsequenceTimeline steps={conseq} />
            </div>
          )}
        </div>
      )}

      {/* Результат: реквизит */}
      {account && (
        <div className="mt-8">
          {account.found && account.account ? (
            <div
              className="fade-up rounded-[24px] p-6 md:p-8"
              style={{
                background: "linear-gradient(180deg, rgba(255,77,77,0.14), rgba(255,255,255,0.015))",
                border: "1px solid rgba(255,77,77,0.4)",
              }}
            >
              <p className="t-label text-[#ff4d4d]">Найдено в народной базе</p>
              <p className="t-heading-sm mt-2 break-all text-white">
                {account.account.value}
              </p>
              <div className="mt-4 flex flex-wrap gap-x-8 gap-y-2 text-[14px] text-[#bdbdbd]">
                <span>Тип: {KIND_LABELS[account.account.kind]}</span>
                <span>
                  Жалоб: <b className="text-white">{account.account.report_count}</b>
                </span>
              </div>
              {account.account.note && (
                <p className="t-body-sm mt-4 text-[#dcdcdc]">
                  «{account.account.note}»
                </p>
              )}
              <p className="mt-5 t-body-sm text-[#ff8a8a]">
                Не переводи деньги и не давай данные. Этот реквизит уже засветился в
                мошеннических схемах.
              </p>
            </div>
          ) : (
            <div
              className="fade-up rounded-[24px] p-6 md:p-8"
              style={{
                background: "linear-gradient(180deg, rgba(53,208,127,0.10), rgba(255,255,255,0.015))",
                border: "1px solid rgba(53,208,127,0.35)",
              }}
            >
              <p className="t-label text-[#35d07f]">В базе пока нет</p>
              <p className="t-subheading mt-2 max-w-xl text-white">
                Этого реквизита нет в народной базе — но это не гарантия. Новые
                схемы появляются каждый день.
              </p>
              <p className="t-body-sm mt-4 text-[#9a9a9a]">
                Определён как: {KIND_LABELS[account.kind as keyof typeof KIND_LABELS] ?? account.kind}.
                Если тебя разводят по нему — добавь его в базу через «Сообщить о схеме».
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
