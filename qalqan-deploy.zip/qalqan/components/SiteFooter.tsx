import Link from "next/link";
import { Logo } from "./Logo";

export function SiteFooter() {
  return (
    <footer className="mt-[120px] border-t border-white/10">
      <div className="mx-auto max-w-[1280px] px-5 py-16 md:px-8">
        <div className="grid gap-12 md:grid-cols-[1.4fr_1fr_1fr]">
          <div>
            <div className="flex items-center gap-3">
              <Logo />
              <span className="text-[19px] font-medium tracking-tight">Qalqan</span>
            </div>
            <p className="t-body-sm mt-4 max-w-sm text-[#9a9a9a]">
              Независимый инструмент против дропперских схем и финансовых пирамид.
              Мы перехватываем в момент вербовки и даём легальную альтернативу.
            </p>
            <p className="mt-4 text-[12px] leading-relaxed text-[#6b6b6b]">
              Qalqan — не официальный сервис АФМ. Мы даём ориентир и
              предупреждение, а не юридическую консультацию.
            </p>
          </div>

          <div>
            <p className="t-label mb-4 text-[#ffb829]">Разделы</p>
            <ul className="space-y-3 text-[14px] text-[#9a9a9a]">
              <li><Link className="hover:text-white" href="/">Проверка</Link></li>
              <li><Link className="hover:text-white" href="/map">Карта угроз</Link></li>
              <li><Link className="hover:text-white" href="/parents">Родителям</Link></li>
            </ul>
          </div>

          <div>
            <p className="t-label mb-4 text-[#ffb829]">Если попал в беду</p>
            <ul className="space-y-3 text-[14px] text-[#9a9a9a]">
              <li>АФМ РК — 1424</li>
              <li>Полиция — 102</li>
              <li>Ст. 232-1 УК РК — дропперство</li>
            </ul>
          </div>
        </div>

        <div className="mt-14 flex flex-col gap-2 border-t border-white/10 pt-6 text-[12px] text-[#6b6b6b] sm:flex-row sm:items-center sm:justify-between">
          <span>© {new Date().getFullYear()} Qalqan. Коллективный щит.</span>
          <span>Сделано для молодёжи Казахстана · RU / ҚАЗ</span>
        </div>
      </div>
    </footer>
  );
}
