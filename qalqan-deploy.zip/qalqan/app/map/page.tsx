import type { Metadata } from "next";
import { ThreatMap } from "@/components/ThreatMap";
import { FlaggedRegistry } from "@/components/FlaggedRegistry";
import { ReportForm } from "@/components/ReportForm";

export const metadata: Metadata = {
  title: "Карта угроз — Qalqan",
  description: "Живая карта активных мошеннических схем по регионам Казахстана.",
};

export default function MapPage() {
  return (
    <div className="mx-auto max-w-[1280px] px-5 md:px-8">
      <section className="py-14 md:py-20">
        <p className="t-label text-[#ffb829]">Карта угроз · живая</p>
        <h1 className="t-heading-lg mt-4 max-w-3xl text-white">
          Где в Казахстане прямо сейчас вербуют.
        </h1>
        <p className="t-body mt-5 max-w-xl text-[#9a9a9a]">
          Каждая проверка и каждый репорт становятся точкой на карте. Размер точки
          — сколько сигналов, цвет — какая схема доминирует. Обновляется в
          реальном времени.
        </p>

        <div className="mt-12">
          <ThreatMap />
        </div>
      </section>

      {/* Народный реестр */}
      <section className="border-t border-white/10 py-16 md:py-20">
        <div className="mb-8 max-w-2xl">
          <p className="t-label text-[#ffb829]">Народный реестр</p>
          <h2 className="t-heading mt-4 text-white">
            Проверь реквизит по засвеченным.
          </h2>
          <p className="t-body mt-4 text-[#9a9a9a]">
            База карт, кошельков, телефонов и ников, на которые уже жаловались.
            Демо работает на сид-данных — в проде это общий реестр в Supabase.
          </p>
        </div>
        <FlaggedRegistry />
      </section>

      {/* Репорт */}
      <section className="border-t border-white/10 py-16 md:py-20">
        <div className="grid gap-10 md:grid-cols-[0.8fr_1.2fr]">
          <div>
            <p className="t-label text-[#ffb829]">Сообщить о схеме</p>
            <h2 className="t-heading mt-4 text-white">
              Столкнулся сам? Предупреди других.
            </h2>
            <p className="t-body mt-4 max-w-md text-[#9a9a9a]">
              Анонимно. Твой сигнал попадёт на карту и в народный реестр — и
              кто-то в твоём городе не поведётся на ту же схему.
            </p>
          </div>
          <ReportForm />
        </div>
      </section>
    </div>
  );
}
