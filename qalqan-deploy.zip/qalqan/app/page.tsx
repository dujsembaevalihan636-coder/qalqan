import Link from "next/link";
import { HeroMap } from "@/components/HeroMap";
import { Checker } from "@/components/Checker";
import { LegalAlternatives } from "@/components/LegalAlternatives";

export default function Home() {
  return (
    <div className="mx-auto max-w-[1280px] px-5 md:px-8">
      {/* ── HERO ── */}
      <section className="relative grid items-center gap-8 pb-16 pt-10 md:min-h-[78vh] md:grid-cols-[1.05fr_0.95fr] md:pt-8">
        <div className="relative z-10 fade-up">
          <p className="t-label text-[#ffb829]">
            Қалқан · щит от дропперских схем
          </p>
          <h1 className="t-display mt-5 text-white">
            Тебя разводят.
            <br />
            Проверь за 5 секунд.
          </h1>
          <p className="t-body mt-6 max-w-lg text-[#bdbdbd]">
            «Лёгкий заработок», «дай карту», «прими и переведи» — так вербуют
            подростков в дропперы. Мы работаем в том же чате, где тебя
            уговаривают, и показываем правду до того, как станет поздно.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-6">
            <Link href="#checker" className="btn-iris">
              Проверить сообщение
            </Link>
            <Link href="/map" className="btn-ghost">
              Карта угроз Казахстана →
            </Link>
          </div>
        </div>

        <div className="relative h-[340px] w-full md:h-[520px]">
          <HeroMap />
        </div>
      </section>

      {/* ── ПРОВЕРКА (модуль A) ── */}
      <section className="border-t border-white/10 py-16 md:py-24">
        <div className="grid gap-10 md:grid-cols-[0.8fr_1.2fr]">
          <div>
            <p className="t-label text-[#ffb829]">Проверка</p>
            <h2 className="t-heading mt-4 text-white">
              Одно сообщение решает,
              <br />
              станешь ли ты соучастником.
            </h2>
            <p className="t-body mt-5 max-w-md text-[#9a9a9a]">
              Вставь текст или введи реквизит. Claude разберёт схему на красные
              флаги простым языком и даст три вопроса, которые нужно задать до
              того, как ты согласишься. Каждая проверка анонимно усиливает общую
              карту угроз.
            </p>
          </div>
          <Checker />
        </div>
      </section>

      {/* ── КАК ЭТО РАБОТАЕТ ── */}
      <section className="border-t border-white/10 py-16 md:py-24">
        <p className="t-label text-[#ffb829]">Коллективный щит</p>
        <h2 className="t-heading mt-4 max-w-2xl text-white">
          Каждая твоя проверка защищает всех остальных.
        </h2>
        <div className="mt-12 grid gap-10 md:grid-cols-3">
          {[
            {
              n: "01",
              t: "Проверяешь",
              d: "Вставляешь подозрительное сообщение — получаешь вердикт-светофор, красные флаги и чек-лист.",
            },
            {
              n: "02",
              t: "Видишь последствия",
              d: "Один клик — и перед тобой таймлайн: от 5 000 ₸ сегодня до дела по ст. 232-1 и судимости.",
            },
            {
              n: "03",
              t: "Усиливаешь карту",
              d: "Твоя анонимная проверка мгновенно появляется точкой на карте — регион узнаёт об активной схеме.",
            },
          ].map((s) => (
            <div key={s.n}>
              <p className="t-heading-lg text-[#8052ff]">{s.n}</p>
              <p className="t-subheading mt-3 text-white">{s.t}</p>
              <p className="t-body-sm mt-2 max-w-xs text-[#9a9a9a]">{s.d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── ЛЕГАЛЬНАЯ АЛЬТЕРНАТИВА (модуль F) ── */}
      <section className="border-t border-white/10 py-16 md:py-24">
        <div className="mb-12 max-w-2xl">
          <p className="t-label text-[#35d07f]">Вместо развода</p>
          <h2 className="t-heading mt-4 text-white">
            Мы не просто говорим «нет». Показываем, где заработать честно.
          </h2>
          <p className="t-body mt-5 text-[#9a9a9a]">
            После красного вердикта важно дать выход. Вот проверенные направления
            легальной подработки для подростков — без карт-дропов и «процентов за
            перевод».
          </p>
        </div>
        <LegalAlternatives />
      </section>
    </div>
  );
}
