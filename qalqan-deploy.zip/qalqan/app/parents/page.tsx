import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Родителям — Qalqan",
  description: "Признаки того, что ребёнка вербуют в дропперы, и что ему сказать.",
};

const SIGNS = [
  "Внезапно появились деньги, которые он не может внятно объяснить.",
  "Оформил новую карту Kaspi или просит родителей оформить на них.",
  "Много переписывается в Telegram с «работодателем», нервничает из-за сообщений.",
  "Говорит про «лёгкую удалёнку», «просто принять перевод», «10% с оборота».",
  "Просит никому не рассказывать про новую «подработку».",
  "Резко скрытный про телефон и банковские приложения.",
];

const SAY = [
  {
    dont: "«Ты что, дурак? Тебя разводят!»",
    do: "«Слушай, я не ругаю. Покажи, что за работа — давай вместе глянем, всё ли чисто.»",
    why: "Обвинение закрывает подростка. Союз — открывает.",
  },
  {
    dont: "«Не смей ничего делать в интернете за деньги.»",
    do: "«Заработать — норм. Давай найдём легальный вариант, где не просят твою карту.»",
    why: "Запрет толкает делать тайком. Альтернатива снимает саму мотивацию рисковать.",
  },
  {
    dont: "«Разберёшься сам, ты уже взрослый.»",
    do: "«Если уже дал карту — это не конец. Сейчас вместе решим, кому позвонить.»",
    why: "Дропперы давят стыдом. Ребёнку нужно знать, что дома помогут, а не накажут.",
  },
];

export default function ParentsPage() {
  return (
    <div className="mx-auto max-w-[1280px] px-5 md:px-8">
      <section className="py-14 md:py-20">
        <p className="t-label text-[#ffb829]">Родителям</p>
        <h1 className="t-heading-lg mt-4 max-w-3xl text-white">
          Как понять, что ребёнка вербуют.
        </h1>
        <p className="t-body mt-5 max-w-xl text-[#9a9a9a]">
          Дропперов ищут среди 16–20-летних: им обещают лёгкие деньги, а они
          становятся соучастниками по ст. 232-1 УК РК — до 7 лет. Вот на что
          смотреть и как говорить.
        </p>
      </section>

      {/* признаки */}
      <section className="border-t border-white/10 py-14 md:py-16">
        <h2 className="t-heading text-white">6 признаков вербовки</h2>
        <div className="mt-10 grid gap-6 md:grid-cols-2">
          {SIGNS.map((s, i) => (
            <div key={i} className="flex gap-4">
              <span className="t-heading-sm shrink-0 text-[#8052ff]">
                {String(i + 1).padStart(2, "0")}
              </span>
              <p className="t-body pt-1 text-[#dcdcdc]">{s}</p>
            </div>
          ))}
        </div>
      </section>

      {/* что сказать */}
      <section className="border-t border-white/10 py-14 md:py-16">
        <h2 className="t-heading text-white">Что сказать вместо ссоры</h2>
        <p className="t-body mt-4 max-w-xl text-[#9a9a9a]">
          Реакция решает всё. Обвинишь — ребёнок замкнётся и пойдёт до конца
          тайком. Поддержишь — успеешь остановить.
        </p>
        <div className="mt-10 space-y-8">
          {SAY.map((s, i) => (
            <div key={i} className="grid gap-4 md:grid-cols-2">
              <div className="rounded-[20px] border border-[#ff4d4d]/25 p-5">
                <p className="t-label text-[#ff4d4d]">Не так</p>
                <p className="t-body mt-2 text-[#dcdcdc]">{s.dont}</p>
              </div>
              <div className="rounded-[20px] border border-[#35d07f]/30 p-5">
                <p className="t-label text-[#35d07f]">А так</p>
                <p className="t-body mt-2 text-[#dcdcdc]">{s.do}</p>
                <p className="t-caption mt-3 text-[#6b6b6b]">{s.why}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="border-t border-white/10 py-14 md:py-16">
        <div className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-center">
          <div>
            <h2 className="t-heading max-w-xl text-white">
              Нашли подозрительную переписку? Проверьте её вместе.
            </h2>
            <p className="t-body mt-3 text-[#9a9a9a]">
              Вставьте сообщение — покажем, схема ли это, простым языком.
            </p>
          </div>
          <Link href="/#checker" className="btn-iris shrink-0">
            Открыть проверку
          </Link>
        </div>
      </section>
    </div>
  );
}
