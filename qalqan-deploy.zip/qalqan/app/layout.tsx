import type { Metadata, Viewport } from "next";
import { Unbounded, Golos_Text } from "next/font/google";
import "./globals.css";
import { Nav } from "@/components/Nav";
import { SiteFooter } from "@/components/SiteFooter";

// Заголовки — Unbounded: скульптурный дисплейный шрифт с сильной кириллицей,
// намеренно НЕ дефолтный «ИИ-шный» гротеск. Текст — Golos Text (родная кириллица).
const display = Unbounded({
  subsets: ["latin", "cyrillic"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-display",
  display: "swap",
});

const body = Golos_Text({
  subsets: ["latin", "cyrillic"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-body",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Qalqan — щит от дропперских схем и пирамид",
  description:
    "Проверь подозительное сообщение, посмотри реальные последствия и загляни на карту активных мошеннических схем Казахстана.",
};

export const viewport: Viewport = {
  themeColor: "#000000",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ru" className={`${display.variable} ${body.variable}`}>
      <body>
        <Nav />
        <main>{children}</main>
        <SiteFooter />
      </body>
    </html>
  );
}
