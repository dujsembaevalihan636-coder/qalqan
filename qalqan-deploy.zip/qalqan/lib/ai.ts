import "server-only";
import Anthropic from "@anthropic-ai/sdk";
import type { AnalysisResult, ConsequenceStep, SchemeType, Verdict } from "./types";
import { normalizeRegion } from "./kz";

const apiKey = process.env.ANTHROPIC_API_KEY;
const MODEL = process.env.ANTHROPIC_MODEL || "claude-sonnet-5";

export const claudeEnabled = Boolean(apiKey);

let _client: Anthropic | null = null;
function claude(): Anthropic {
  if (!_client) _client = new Anthropic({ apiKey });
  return _client;
}

// Безопасно вытащить JSON из ответа модели: срезать ```json ограждения и распарсить.
function safeParseJson<T>(raw: string): T | null {
  let s = raw.trim();
  const fence = s.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fence) s = fence[1].trim();
  // на случай префикса/суффикса — берём от первой { до последней }
  const first = s.indexOf("{");
  const firstArr = s.indexOf("[");
  const start =
    first === -1 ? firstArr : firstArr === -1 ? first : Math.min(first, firstArr);
  if (start > 0) s = s.slice(start);
  const lastObj = s.lastIndexOf("}");
  const lastArr = s.lastIndexOf("]");
  const end = Math.max(lastObj, lastArr);
  if (end !== -1) s = s.slice(0, end + 1);
  try {
    return JSON.parse(s) as T;
  } catch {
    return null;
  }
}

// ─────────────────────────────────────────────────────────────
// АНАЛИЗ СООБЩЕНИЯ
// ─────────────────────────────────────────────────────────────

const ANALYZE_SYSTEM = `Ты — эксперт по финансовому мошенничеству в Казахстане, который помогает подросткам (16–20 лет) распознать вербовку в дропперские схемы, финансовые пирамиды, фишинг и фейковые вакансии.

Контекст Казахстана: Kaspi (карты и переводы), статья 232-1 УК РК (дропперство — до 7 лет), АФМ (Агентство по финансовому мониторингу). Типичные формулировки вербовки на русском и казахском: «лёгкий заработок», «дай карту / прими и переведи, оставишь 10%», «удалёнка без опыта, 300–500к», «инвестиции 30% в месяц», «нужна твоя карта на один перевод».

Оцени присланное сообщение и верни СТРОГО валидный JSON без markdown, без ограждений, без преамбулы, по схеме:
{
  "verdict": "red" | "yellow" | "green",
  "summary": "одна короткая строка простым языком подростка — что это",
  "redFlags": ["2–4 красных флага простым языком, конкретно по этому тексту"],
  "checklist": ["ровно 3 вопроса, которые надо задать себе/собеседнику ПЕРЕД тем как соглашаться"],
  "schemeType": "dropper" | "pyramid" | "phishing" | "fake_job" | "other",
  "region": "город/область если упомянут, иначе null"
}

Правила: red — явная вербовка/мошенничество; yellow — подозрительно, не хватает данных; green — похоже на легальное предложение. Пиши на русском, коротко, без канцелярита и морали. Не выдумывай флагов, которых нет в тексте.`;

export async function analyzeMessage(text: string): Promise<AnalysisResult> {
  if (claudeEnabled) {
    try {
      const msg = await claude().messages.create({
        model: MODEL,
        max_tokens: 700,
        system: ANALYZE_SYSTEM,
        messages: [{ role: "user", content: text }],
      });
      const raw = msg.content
        .filter((b) => b.type === "text")
        .map((b) => (b as { text: string }).text)
        .join("\n");
      const parsed = safeParseJson<Omit<AnalysisResult, "engine">>(raw);
      if (parsed && parsed.verdict) {
        return {
          verdict: parsed.verdict,
          summary: parsed.summary ?? "",
          redFlags: parsed.redFlags?.slice(0, 4) ?? [],
          checklist: parsed.checklist?.slice(0, 3) ?? [],
          schemeType: parsed.schemeType ?? "other",
          region: normalizeRegion(parsed.region) ?? parsed.region ?? null,
          engine: "claude",
        };
      }
    } catch (e) {
      console.error("[ai] analyze via claude failed, falling back:", e);
    }
  }
  return heuristicAnalyze(text);
}

// ── Эвристика (без ключа): ключевые маркеры вербовки ──
// ВАЖНО: в JS \w и \b НЕ матчат кириллицу, поэтому вместо них — классы
// [а-яёa-z] и мягкие разделители. Иначе маркеры молча не срабатывают.
const W = "[а-яёa-z]"; // «буква слова» с кириллицей
const MARKERS: { re: RegExp; scheme: SchemeType; flag: string; weight: number }[] = [
  { re: new RegExp(`(дай|нужн${W}*|скинь|отправь|фото|дать|давай)[^.!?]{0,12}(карт|kaspi|каспи|каспий)`, "i"), scheme: "dropper", flag: "Просят твою карту или её данные — это признак дропперской схемы", weight: 3 },
  { re: new RegExp(`при[нм]${W}*[ \\u00A0]+перевод|перекин|обнал|перевод${W}*[ \\u00A0]+дальше`, "i"), scheme: "dropper", flag: "«Прими и переведи» — тебя делают дроппером (ст. 232-1 УК РК)", weight: 3 },
  { re: new RegExp(`(остав${W}*|получ${W}*|твои)[^.!?]{0,10}\\d{1,2}\\s*%`, "i"), scheme: "dropper", flag: "Обещают процент за «прогон» денег через тебя", weight: 2 },
  { re: new RegExp(`л[её]гк${W}*[ \\u00A0]+(заработ${W}*|деньг${W}*)|лёгкие деньги|быстр${W}*[ \\u00A0]+заработ`, "i"), scheme: "fake_job", flag: "«Лёгкий/быстрый заработок» — типичная приманка вербовщика", weight: 2 },
  { re: new RegExp(`(удал[её]нк${W}*|работ${W}*|подработк${W}*)[^.!?]{0,25}(без опыта|на дому)|ваканси`, "i"), scheme: "fake_job", flag: "«Работа без опыта на дому» с большой оплатой — фейковая вакансия", weight: 2 },
  { re: new RegExp(`(150|200|250|300|400|500|600|700)\\s*к(?!${W})|\\d{2,3}\\s*000\\s*(тенге|₸|в день|в неделю|в месяц)`, "i"), scheme: "fake_job", flag: "Нереально большая оплата за простую задачу", weight: 2 },
  { re: new RegExp(`(20|30|40|50)\\s*%[^.!?]{0,10}(в месяц|прибыл|сверху|доход)|инвест${W}*[^.!?]{0,20}гаранти|гаранти${W}*[^.!?]{0,20}(доход|процент|прибыл)`, "i"), scheme: "pyramid", flag: "Гарантированная сверхприбыль — верный признак пирамиды", weight: 3 },
  { re: new RegExp(`пирамид|привед${W}*[^.!?]{0,10}(друг|друз)|реферал${W}*[^.!?]{0,20}(доход|бонус)|привед${W}*[^.!?]{0,10}(ещ|бонус)`, "i"), scheme: "pyramid", flag: "Доход «за приглашённых друзей» — это пирамида", weight: 2 },
  { re: new RegExp(`код из смс|код${W}*[^.!?]{0,8}(из )?(смс|sms)|подтверд${W}*[^.!?]{0,8}код|данные карт|cvv|срок действия карт|продиктуй`, "i"), scheme: "phishing", flag: "Просят код из SMS / данные карты — это кража доступа к деньгам", weight: 3 },
  { re: new RegExp(`служб${W}*[^.!?]{0,12}безопасност|банк${W}*[^.!?]{0,15}(заблокир|подозрительн)|подозрительн${W}*[^.!?]{0,10}операц`, "i"), scheme: "phishing", flag: "«Служба безопасности банка» — классический фишинговый предлог", weight: 2 },
  { re: new RegExp(`срочно|только сегодня|мест${W}*[^.!?]{0,8}(мало|остал)|успей|поспеш`, "i"), scheme: "other", flag: "Давят срочностью, чтобы ты не успел подумать", weight: 1 },
  { re: new RegExp(`никому не говор|это секрет|не рассказ${W}*[^.!?]{0,15}(родител|друз|никому)|конкуренци`, "i"), scheme: "other", flag: "Просят держать в тайне — чтобы никто не отговорил", weight: 2 },
];

function heuristicAnalyze(text: string): AnalysisResult {
  const flags: string[] = [];
  const schemeScore: Record<SchemeType, number> = {
    dropper: 0, pyramid: 0, phishing: 0, fake_job: 0, other: 0,
  };
  let score = 0;
  for (const m of MARKERS) {
    if (m.re.test(text)) {
      flags.push(m.flag);
      score += m.weight;
      schemeScore[m.scheme] += m.weight;
    }
  }
  let scheme: SchemeType = "other";
  let best = 0;
  (Object.keys(schemeScore) as SchemeType[]).forEach((k) => {
    if (schemeScore[k] > best) { best = schemeScore[k]; scheme = k; }
  });

  let verdict: Verdict = "green";
  if (score >= 4) verdict = "red";
  else if (score >= 2) verdict = "yellow";

  const summaries: Record<Verdict, string> = {
    red: "Похоже на вербовку в мошенническую схему. Не соглашайся и не давай карту.",
    yellow: "Есть подозрительные признаки. Не спеши — сначала проверь.",
    green: "Явных признаков развода не видно, но всё равно будь внимателен.",
  };

  const checklist =
    verdict === "green"
      ? [
          "Кто именно платит и за какую конкретную работу?",
          "Есть ли у компании реальные контакты и договор?",
          "Не просят ли на каком-то шаге карту, код или предоплату?",
        ]
      : [
          "Зачем им МОЯ карта/данные, если это «просто работа»?",
          "Что будет со мной, если через мою карту пройдут чужие деньги?",
          "Могу ли я показать это сообщение родителям — почему нет?",
        ];

  return {
    verdict,
    summary: summaries[verdict],
    redFlags: flags.slice(0, 4).length
      ? flags.slice(0, 4)
      : ["Явных маркеров вербовки не найдено — но проверь, кто и за что платит."],
    checklist,
    schemeType: scheme,
    region: normalizeRegion(text),
    engine: "heuristic",
  };
}

// ─────────────────────────────────────────────────────────────
// ПОСЛЕДСТВИЯ (таймлайн по ст. 232-1)
// ─────────────────────────────────────────────────────────────

const CONSEQ_SYSTEM = `Ты показываешь подростку в Казахстане реалистичную траекторию последствий, если он согласится стать «дроппером» (даст свою карту / примет и переведёт чужие деньги) — на основе статьи 232-1 УК РК.

Верни СТРОГО валидный JSON-массив из 4–6 шагов, без markdown и преамбулы:
[
  { "time": "сегодня", "event": "короткий заголовок", "detail": "1 предложение пояснения", "severity": "info" | "warning" | "danger" }
]

Тон: трезвый, фактический, без запугивания сверх меры и без морали. От «получил первые деньги» до «заморозка счёта», «вызов в АФМ / уголовное дело по 232-1», «судимость», «невыездной, проблемы с работой и кредитами». severity растёт от info к danger. Пиши на русском, коротко.`;

export async function generateConsequences(scenario: string): Promise<ConsequenceStep[]> {
  if (claudeEnabled) {
    try {
      const msg = await claude().messages.create({
        model: MODEL,
        max_tokens: 800,
        system: CONSEQ_SYSTEM,
        messages: [{ role: "user", content: scenario || "Согласился стать дроппером: дал свою карту и принял чужой перевод за 10%." }],
      });
      const raw = msg.content
        .filter((b) => b.type === "text")
        .map((b) => (b as { text: string }).text)
        .join("\n");
      const parsed = safeParseJson<ConsequenceStep[]>(raw);
      if (Array.isArray(parsed) && parsed.length) {
        return parsed.slice(0, 6).map((s) => ({
          time: s.time ?? "",
          event: s.event ?? "",
          detail: s.detail ?? "",
          severity: (["info", "warning", "danger"] as const).includes(s.severity as never)
            ? s.severity
            : "warning",
        }));
      }
    } catch (e) {
      console.error("[ai] consequences via claude failed, falling back:", e);
    }
  }
  return DEFAULT_CONSEQUENCES;
}

const DEFAULT_CONSEQUENCES: ConsequenceStep[] = [
  { time: "Сегодня", event: "Получил первые 5 000 ₸", detail: "«Всё легко» — ты дал карту или принял перевод и оставил себе процент.", severity: "info" },
  { time: "Через 2–8 недель", event: "Заморозка счёта", detail: "Банк и АФМ видят подозрительные операции — твоя карта и Kaspi блокируются.", severity: "warning" },
  { time: "Через 1–3 месяца", event: "Вызов в АФМ", detail: "Тебя вызывают на допрос: по документам деньги проходили через ТЕБЯ.", severity: "warning" },
  { time: "Далее", event: "Дело по ст. 232-1 УК РК", detail: "Дропперство — до 7 лет лишения свободы. Отвечает владелец карты, а не «работодатель».", severity: "danger" },
  { time: "Годы после", event: "Судимость и её шлейф", detail: "Невыездной, отказ в кредитах и ипотеке, проблемы с трудоустройством.", severity: "danger" },
];
